(function() {
  'use strict';

  // ── State ───────────────────────────────────────────────────────────────────
  let odIndex = null, oIndex = null, brokerIndex = null;
  let senderEmail = '', emailTemplate = '', senderGmailIndex = 0;
  let userName = '', userCompany = '';
  let gmailIndex = 0;
  let panel = null;
  let panelBodyHTML = '';
  let isDragging = false, dragOffX = 0, dragOffY = 0;
  let isResizing = false, resizeRightEdge = 0, resizeCorner = false;
  let processed = new WeakSet();
  let _dlmT;

  // ── City normalizer ─────────────────────────────────────────────────────────
  function norm(raw) {
    if (!raw) return '';
    return String(raw).toLowerCase()
      // Expand DAT abbreviations before state stripping (mt must come first —
      // it is also Montana's state code and would otherwise be stripped)
      .replace(/\bmt\b/g,   'mount')
      .replace(/\bmtn\b/g,  'mountain')
      .replace(/\bft\b/g,   'fort')
      .replace(/\bpt\b/g,   'point')
      .replace(/\blk\b/g,   'lake')
      .replace(/\bcyn\b/g,  'canyon')
      .replace(/\bvly\b/g,  'valley')
      .replace(/\bbch\b/g,  'beach')
      .replace(/\bhls\b/g,  'hills')
      .replace(/\bhts\b/g,  'heights')
      .replace(/\bhgts\b/g, 'heights')
      .replace(/\bspgs\b/g, 'springs')
      .replace(/\bspg\b/g,  'spring')
      .replace(/\bvlg\b/g,  'village')
      .replace(/\bjct\b/g,  'junction')
      .replace(/\b(ca|fl|tx|pa|nv|ga|nc|va|ct|mi|in|oh|mo|co|az|or|ut|wa|mn|ne|ks|sc|al|ms|la|ar|ky|tn|wv|md|nj|ny|ma|ri|nh|vt|me|de|nm|id|mt|wy|sd|nd|ok|ia|il|ak|hi|dc|wi)\b/g, '')
      .replace(/\d+/g, '').replace(/[^a-z\s]/g, ' ').replace(/\s+/g, ' ').trim();
  }

  // Extract state from city string e.g. "Charlotte, NC" -> "nc"
  function getState(raw) {
    const m = String(raw).match(/([A-Z]{2})\s*$/);
    return m ? m[1].toLowerCase() : '';
  }

  function citiesMatch(a, b) {
    const sa = getState(a), sb = getState(b);
    if (sa && sb && sa !== sb) return false;

    const na = norm(a), nb = norm(b);
    if (!na || !nb || na.length < 2 || nb.length < 2) return false;
    return na === nb;
  }

  function normBroker(raw) {
    if (!raw || raw === 'nan') return '';
    return String(raw).toLowerCase()
      .replace(/logistics|transport|brokerage|freight|group|inc|llc|corp|co/gi, '')
      .replace(/[^a-z\s]/g, ' ').replace(/\s+/g, ' ').trim();
  }

  // ── Lookup functions ────────────────────────────────────────────────────────
  function findOD(origin, dest) {
    if (!odIndex) return [];
    const no = norm(origin), nd = norm(dest);
    if (!no || !nd) return [];
    const out = [];
    for (const [key, recs] of Object.entries(odIndex)) {
      const [ko, kd] = key.split('|');
      if (citiesMatch(no, ko) && citiesMatch(nd, kd)) out.push(...recs);
    }
    return dedup(out);
  }

  function findO(origin) {
    if (!oIndex) return [];
    const no = norm(origin);
    if (!no) return [];
    const out = [];
    for (const [key, recs] of Object.entries(oIndex)) {
      if (citiesMatch(no, key)) out.push(...recs);
    }
    return dedup(out).slice(0, 15);
  }

  function findBroker(brokerName, origin) {
    if (!brokerIndex || !brokerName) return [];
    const nb = normBroker(brokerName);
    if (!nb || nb.length < 2) return [];
    const no = norm(origin || '');
    const out = [];
    for (const [key, recs] of Object.entries(brokerIndex)) {
      const nk = normBroker(key);
      if (nk && (nk.includes(nb) || nb.includes(nk))) {
        // Only include if origin region roughly matches
        const sameRegion = recs.some(r => citiesMatch(r.origin || '', origin || ''));
        if (sameRegion) out.push(...recs);
      }
    }
    return dedup(out).slice(0, 10);
  }

  function dedup(recs) {
    const seen = new Set();
    return recs
      .filter(r => { const k = r.loadNum || (r.origin + '|' + (r.destination || '') + '|' + r.puDate); if (seen.has(k)) return false; seen.add(k); return true; })
      .sort((a, b) => parseDate(b.puDate) - parseDate(a.puDate));
  }

  function parseDate(raw) {
    if (!raw) return 0;
    const s = String(raw).trim();
    let m;
    m = s.match(/^(\d{4})-(\d{2})-(\d{2})/); if (m) return new Date(+m[1],+m[2]-1,+m[3]).getTime();
    m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/); if (m) return new Date(+m[3],+m[1]-1,+m[2]).getTime();
    m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2})\b/); if (m) return new Date(2000+(+m[3]),+m[1]-1,+m[2]).getTime();
    m = s.match(/([A-Za-z]{3,9})\s+(\d{1,2})[,\s]+(\d{4})/); if (m) { const d = new Date(m[1]+' '+m[2]+' '+m[3]); if (!isNaN(d)) return d.getTime(); }
    m = s.match(/^(\d{1,2})\/(\d{1,2})\b/); if (m) return new Date(new Date().getFullYear(),+m[1]-1,+m[2]).getTime();
    const d = new Date(s); return isNaN(d) ? 0 : d.getTime();
  }

  function calcStats(recs) {
    const rates = recs.map(r => parseFloat(String(r.rate).replace(/[^0-9.]/g, ''))).filter(r => r > 0);
    return {
      count: recs.length,
      avg:  rates.length ? '$' + Math.round(rates.reduce((a,b)=>a+b,0)/rates.length).toLocaleString() : 'N/A',
      best: rates.length ? '$' + Math.max(...rates).toLocaleString() : 'N/A',
    };
  }

  function esc(s) { return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

  function gmailUrl(loadNum) {
    const q = String(loadNum||'').replace(/[^a-zA-Z0-9]/g, '').trim();
    if (!q) return null;
    return `https://mail.google.com/mail/u/${gmailIndex}/#search/${encodeURIComponent(q)}`;
  }

  // ── Clean DAT's special characters from city text ────────────────────────
  function cleanCity(str) {
    let s = String(str || '')
      .replace(/[^\x00-\x7F]/g, '')
      .replace(/\s+/g, ' ')
      .trim();
    // Remove exact duplicate e.g. "Salinas, CA Salinas, CA"
    let m = s.match(/^(.+?,\s*[A-Z]{2})\s+\1/i);
    if (m) return m[1].trim();
    // Remove partial duplicate e.g. "Salinas, CA Salinas" — but not "Sacramento, CA Stockton, CA"
    m = s.match(/^([\w\s\.]+,\s*[A-Z]{2})\s+([\w\s]+)$/);
    if (m && !/,\s*[A-Z]{2}$/.test(m[2])) return m[1].trim();
    return s;
  }

  // ── Send email via Gmail compose URL ──────────────────────────────────────
  function sendEmail(brokerEmail, originRaw, destRaw) {
    const origin  = cleanCity(originRaw);
    const dest    = cleanCity(destRaw);
    const subject = `Interested in Load from ${origin} to ${dest}`;
    const body    = emailTemplate
      .replace(/\{origin\}/g, origin)
      .replace(/\{destination\}/g, dest)
      .replace(/\{name\}/g, userName)
      .replace(/\{company\}/g, userCompany);

    const acct = senderGmailIndex;
    const url  = `https://mail.google.com/mail/u/${acct}/?view=cm&fs=1` +
                 `&to=${encodeURIComponent(brokerEmail)}` +
                 `&su=${encodeURIComponent(subject)}` +
                 `&body=${encodeURIComponent(body)}`;
    window.open(url, '_blank');
  }

    // ── Extract broker email from DAT row ──────────────────────────────────────
  function getBrokerEmail(row) {
    // 1. Check mailto links first
    const mailtoEl = row.querySelector('a[href^="mailto:"]');
    if (mailtoEl) {
      const email = mailtoEl.href.replace('mailto:', '').split('?')[0].trim();
      if (email && email.includes('@')) return email;
    }
    // 2. Check contact column
    const contactEl = row.querySelector('[class*="contact"],[class*="Contact"],[class*="email"],[class*="Email"]');
    if (contactEl) {
      const m = contactEl.textContent.match(/[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/);
      if (m) return m[0];
    }
    // 3. Scan full row text
    const matches = row.textContent.match(/[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g) || [];
    const filtered = matches.filter(e =>
      !e.includes('dat.com') && !e.includes('google.com') &&
      !e.includes('optimizely.com') && !e.includes('example.com')
    );
    return filtered[0] || '';
  }

    // ── Make broker email addresses clickable on ALL rows ─────────────────────
  function injectEmailButton(row) {
    if (row.dataset.dlmEmail) return;

    const brokerEmail = getBrokerEmail(row);
    if (!brokerEmail) return;

    const { origin, dest } = getCities(row);
    if (!origin) return;

    row.dataset.dlmEmail = brokerEmail;

    // Listen for clicks anywhere on the row
    // If the click lands on or near the email text, open Gmail
    row.addEventListener('click', e => {
      const clickedText = e.target.textContent.trim();
      const rowEmail = row.dataset.dlmEmail;
      if (!rowEmail) return;

      // Check if clicked element contains the email
      if (clickedText.includes('@') && clickedText.includes('.') &&
          clickedText.replace(/\s+/g,'').includes(rowEmail.replace(/\s+/g,''))) {
        e.stopPropagation();
        e.preventDefault();
        sendEmail(rowEmail, origin, dest || 'destination');
        return;
      }

      // Also check parent elements up 3 levels
      let el = e.target;
      for (let i = 0; i < 3; i++) {
        if (!el) break;
        if (el.textContent && el.textContent.includes(rowEmail)) {
          const rect = el.getBoundingClientRect();
          const clickX = e.clientX;
          // Only if click is within reasonable bounds of the email element
          if (clickX >= rect.left - 5 && clickX <= rect.right + 5) {
            e.stopPropagation();
            e.preventDefault();
            sendEmail(rowEmail, origin, dest || 'destination');
            return;
          }
        }
        el = el.parentElement;
      }
    }, true); // useCapture to intercept before DAT's handlers
  }

    // ── Extract origin/destination from DAT row ─────────────────────────────────
  function getCities(row) {
    // Primary: confirmed selectors from HTML inspector
    const oEl = row.querySelector('div[class="origin"], [class*="origin"] .truncate, [class*="origin"]');
    const dEl = row.querySelector('div[class="destination"], [class*="destination"] .truncate, [class*="destination"]');

    let origin = oEl ? oEl.textContent.trim() : '';
    let dest   = dEl ? dEl.textContent.trim() : '';

    // Clean up — remove DH-O numbers that get mixed in
    origin = origin.replace(/^\d+\s*/, '').trim();
    dest   = dest.replace(/^\d+\s*/, '').trim();

    if (origin.length > 3 && dest.length > 3) return { origin, dest };

    // Fallback: regex scan on row text
    const text = row.textContent;
    const CITY_RE = /\b([A-Za-z][A-Za-z\s\.]{1,22}),\s*([A-Z]{2})\b/g;
    const cities = [];
    let m;
    CITY_RE.lastIndex = 0;
    while ((m = CITY_RE.exec(text)) !== null && cities.length < 2) {
      const c = m[1].trim();
      if (c.length >= 2 && !['Van','Full','Partial','Reefer','Flat','Step'].includes(c)) {
        cities.push(`${c}, ${m[2]}`);
      }
    }
    return { origin: cities[0] || origin, dest: cities[1] || dest };
  }

  function getBroker(row) {
    const el = row.querySelector('[class*="company"], [class*="Company"], [class*="carrier"]');
    if (el) {
      const t = el.textContent.trim();
      if (t && t.length > 1 && t.length < 80 && !/^\d+$/.test(t)) return t;
    }
    return '';
  }

  // ── Process one row ─────────────────────────────────────────────────────────
  function processRow(row) {
    if (!row || row.offsetWidth < 100) return;

    if (processed.has(row)) return;

    const { origin, dest } = getCities(row);
    if (!origin || origin.length < 3) return;

    processed.add(row);

    const datBroker = getBroker(row);
    const odM = dest ? findOD(origin, dest) : [];
    const oM  = findO(origin);
    const bM  = datBroker ? findBroker(datBroker, origin) : [];

    if (!odM.length && !oM.length && !bM.length) return;

    // Determine tier
    // 🟣 PURPLE = same origin + destination + same broker
    // 🟢 GREEN  = same origin + destination, 3+ times
    // 🟡 YELLOW = same origin + destination, 1-2 times
    // 🔵 BLUE   = same origin city + state only
    let cls, badgeCls, badgeTxt;

    const normDatBroker = datBroker ? normBroker(datBroker) : '';
    const normDatFirst = normDatBroker.split(' ')[0];
    const sameLineBroker = normDatFirst && odM.filter(r =>
      r.broker && normBroker(r.broker).includes(normDatFirst)
    );

    if (sameLineBroker && sameLineBroker.length > 0) {
      cls = 'dlm-purple'; badgeCls = 'dlm-b-purple';
      badgeTxt = `🔥 ${odM.length}x · ${datBroker.split(' ')[0]}`;
    } else if (odM.length >= 3) {
      cls = 'dlm-green';  badgeCls = 'dlm-b-green';  badgeTxt = `✓ ${odM.length}x`;
    } else if (odM.length >= 1) {
      cls = 'dlm-yellow'; badgeCls = 'dlm-b-yellow'; badgeTxt = `✓ ${odM.length}x`;
    } else if (oM.length >= 1) {
      cls = 'dlm-blue'; // no badge for blue tier
    } else {
      return;
    }

    row.classList.add(cls);

    // Add badge — append to origin container (never inside .truncate, which clips long city names)
    if (badgeTxt) {
      const oEl = row.querySelector('div[class="origin"], [class*="origin"]') || row;
      if (!oEl.querySelector('.dlm-badge')) {
        oEl.classList.add('dlm-badge-host');
        const badge = document.createElement('span');
        badge.className = `dlm-badge ${badgeCls}`;
        badge.textContent = badgeTxt;
        oEl.appendChild(badge);
      }
    }

    row.dataset.dlmOrigin = origin;
    row.dataset.dlmDest = dest || '';
    row.dataset.dlmBroker = datBroker || '';
    if (!row.dataset.dlmBound) {
      row.dataset.dlmBound = '1';
      row.addEventListener('click', e => {
        if (e.target.type === 'checkbox') return;
        const o = row.dataset.dlmOrigin || '';
        const d = row.dataset.dlmDest || '';
        const b = row.dataset.dlmBroker || '';
        if (!o) return;
        showPanel(o, d, d ? findOD(o, d) : [], findO(o), b ? findBroker(b, o) : [], b);
      });
    }
  }

  // ── Search ───────────────────────────────────────────────────────────────────
  function searchHistory(query) {
    if (!oIndex) return [];
    const q = query.toLowerCase().trim();
    if (q.length < 2) return [];
    const seen = new Set();
    const results = [];
    for (const recs of Object.values(oIndex)) {
      for (const r of recs) {
        const key = r.loadNum || (r.origin + r.puDate);
        if (seen.has(key)) continue;
        if ((r.origin      || '').toLowerCase().includes(q) ||
            (r.destination || '').toLowerCase().includes(q) ||
            (r.broker      || '').toLowerCase().includes(q)) {
          seen.add(key);
          results.push(r);
        }
      }
    }
    return results.sort((a, b) => parseDate(b.puDate) - parseDate(a.puDate)).slice(0, 50);
  }

  function showSearchResults(query) {
    const results = searchHistory(query);
    const body = document.getElementById('dlm-body');
    if (!results.length) {
      body.innerHTML = `<div style="text-align:center;padding:36px 20px;color:#aeaeb2;font-size:13px;line-height:1.6">No results for<br><strong style="color:#6e6e73;font-weight:600">${esc(query)}</strong></div>`;
      return;
    }
    const st = calcStats(results);
    const cap = results.length >= 50;
    body.innerHTML = `
      <div class="dlm-sum">
        <div style="font-size:10px;color:#aeaeb2;letter-spacing:.05em;text-transform:uppercase;margin-bottom:8px;font-weight:600">Search</div>
        <div class="dlm-lane" style="color:#6e6e73">${esc(query)}</div>
        <div class="dlm-stats">
          <div><div class="dlm-sv">${cap ? '50+' : results.length}</div><div class="dlm-sl">Results</div></div>
          <div><div class="dlm-sv">${st.avg}</div><div class="dlm-sl">Avg Rate</div></div>
          <div><div class="dlm-sv">${st.best}</div><div class="dlm-sl">Best Rate</div></div>
        </div>
      </div>
      <div class="dlm-stitle">Matching Loads${cap ? ' · Top 50' : ''}</div>
      ${renderRecs(results, '#c7c7cc', 50)}`;
  }

  // ── Panel ───────────────────────────────────────────────────────────────────
  function buildPanel() {
    const d = document.createElement('div');
    d.id = 'dlm-panel';
    d.innerHTML = `
      <div id="dlm-resize"></div>
      <div id="dlm-panel-hdr">
        <span id="dlm-title">◈ LANE HISTORY<small> · drag to move</small></span>
        <div style="display:flex;align-items:center;gap:1px">
          <button id="dlm-minimize" title="Minimize">─</button>
          <button id="dlm-close" title="Close">✕</button>
        </div>
      </div>
      <div id="dlm-search-wrap">
        <span style="color:#4b5563;font-size:13px;flex-shrink:0;line-height:1">⌕</span>
        <input id="dlm-search" type="text" placeholder="Search origin, destination, broker…" autocomplete="off" spellcheck="false">
        <button id="dlm-search-clear" title="Clear search">✕</button>
      </div>
      <div id="dlm-body">
        <div style="text-align:center;padding:36px 20px;color:#aeaeb2;font-size:13px;line-height:1.6;letter-spacing:-.01em">
          Click a highlighted row<br>to see booking history
        </div>
      </div>
      <div id="dlm-corner"></div>`;
    document.body.appendChild(d);

    d.querySelector('#dlm-close').addEventListener('click', () => d.style.display = 'none');

    const minBtn = d.querySelector('#dlm-minimize');
    minBtn.addEventListener('click', () => {
      const minimized = d.classList.toggle('dlm-minimized');
      minBtn.textContent = minimized ? '▢' : '─';
      minBtn.title = minimized ? 'Restore' : 'Minimize';
    });

    const searchInput = d.querySelector('#dlm-search');
    const searchClear = d.querySelector('#dlm-search-clear');
    let searchTimer = null;
    searchInput.addEventListener('input', () => {
      clearTimeout(searchTimer);
      const q = searchInput.value.trim();
      searchClear.style.display = q ? 'block' : 'none';
      if (!q) { document.getElementById('dlm-body').innerHTML = panelBodyHTML; return; }
      searchTimer = setTimeout(() => showSearchResults(q), 150);
    });
    searchClear.addEventListener('click', () => {
      searchInput.value = '';
      searchClear.style.display = 'none';
      document.getElementById('dlm-body').innerHTML = panelBodyHTML;
      searchInput.focus();
    });

    const hdr = d.querySelector('#dlm-panel-hdr');
    hdr.addEventListener('mousedown', e => {
      if (e.target.id === 'dlm-close' || e.target.id === 'dlm-minimize') return;
      isDragging = true;
      const r = d.getBoundingClientRect();
      dragOffX = e.clientX - r.left; dragOffY = e.clientY - r.top;
      d.style.transition = 'none'; e.preventDefault();
    });

    function startResize(e, corner) {
      isResizing = true;
      resizeCorner = corner;
      // Capture right edge once — used as fixed anchor throughout the drag
      const rect = d.getBoundingClientRect();
      resizeRightEdge = rect.right;
      // Switch from right-anchored to left-anchored positioning immediately
      d.style.left  = rect.left + 'px';
      d.style.right = 'auto';
      d.classList.add('dlm-resizing');
      e.preventDefault();
      e.stopPropagation();
    }

    d.querySelector('#dlm-resize').addEventListener('mousedown',  e => startResize(e, false));
    d.querySelector('#dlm-corner').addEventListener('mousedown',  e => startResize(e, true));

    document.addEventListener('mousemove', e => {
      if (isDragging) {
        d.style.left  = Math.max(0, Math.min(window.innerWidth  - d.offsetWidth,  e.clientX - dragOffX)) + 'px';
        d.style.top   = Math.max(0, Math.min(window.innerHeight - d.offsetHeight, e.clientY - dragOffY)) + 'px';
        d.style.right = 'auto';
      }
      if (isResizing) {
        const newWidth = Math.max(220, Math.min(560, resizeRightEdge - e.clientX));
        d.style.width = newWidth + 'px';
        d.style.left  = (resizeRightEdge - newWidth) + 'px';
        if (resizeCorner) {
          const top = d.getBoundingClientRect().top;
          d.style.maxHeight = Math.max(150, Math.min(window.innerHeight - top - 10, e.clientY - top)) + 'px';
        }
      }
    });

    document.addEventListener('mouseup', () => {
      isDragging = false;
      if (isResizing) { isResizing = false; resizeCorner = false; d.classList.remove('dlm-resizing'); }
    });

    return d;
  }

  function showPanel(origin, dest, odM, oM, bM, datBroker) {
    if (!panel) panel = buildPanel();
    panel.style.display = 'flex';
    if (panel.classList.contains('dlm-minimized')) {
      panel.classList.remove('dlm-minimized');
      const minBtn = panel.querySelector('#dlm-minimize');
      if (minBtn) { minBtn.textContent = '─'; minBtn.title = 'Minimize'; }
    }
    const titleEl = panel.querySelector('#dlm-title');
    if (titleEl) {
      const laneShort = dest
        ? `${origin.split(',')[0].trim()} → ${dest.split(',')[0].trim()}`
        : origin.split(',')[0].trim();
      titleEl.innerHTML = `◈ ${esc(laneShort)}<small> · drag</small>`;
    }
    const pri = odM.length ? odM : oM.length ? oM : bM;
    const st = calcStats(pri);
    const arrow = dest ? `<span style="color:#aeaeb2;margin:0 5px;font-weight:300">→</span>${esc(dest)}` : '';

    let html = `
      <div class="dlm-sum">
        <div style="font-size:10px;color:#aeaeb2;letter-spacing:.05em;text-transform:uppercase;margin-bottom:8px;font-weight:600">Current Load</div>
        <div class="dlm-lane">${esc(origin)}${arrow}</div>
        <div class="dlm-stats">
          <div><div class="dlm-sv">${st.count}</div><div class="dlm-sl">Bookings</div></div>
          <div><div class="dlm-sv">${st.avg}</div><div class="dlm-sl">Avg Rate</div></div>
          <div><div class="dlm-sv">${st.best}</div><div class="dlm-sl">Best Rate</div></div>
        </div>
      </div>`;

    if (odM.length) html += `<div class="dlm-stitle">Exact Lane Matches · ${odM.length}</div>` + renderRecs(odM, '#34c759');

    // Purple: same lane + same broker
    if (odM.length && bM.length && datBroker) {
      const brokerLane = bM.filter(r => odM.find(o => o.loadNum === r.loadNum));
      if (brokerLane.length) html += `<div class="dlm-stitle" style="color:#af52de">Same Broker — ${esc(datBroker)}</div>`;
    }

    // Blue: same origin city only
    if (!odM.length && oM.length) {
      html += `<div class="dlm-stitle">Same Origin · ${oM.length} loads</div>` + renderRecs(oM, '#007aff');
    } else if (odM.length && oM.length) {
      const originOnly = oM.filter(r => !odM.find(o => o.loadNum === r.loadNum));
      if (originOnly.length) html += `<div class="dlm-stitle">Other Loads from This Origin · ${originOnly.length}</div>` + renderRecs(originOnly, '#007aff');
    }

    panelBodyHTML = html;
    const searchEl = panel.querySelector('#dlm-search');
    if (searchEl && searchEl.value) {
      searchEl.value = '';
      const clearEl = panel.querySelector('#dlm-search-clear');
      if (clearEl) clearEl.style.display = 'none';
    }
    document.getElementById('dlm-body').innerHTML = html;
  }

  function renderRecs(list, color, limit = 20) {
    return list.slice(0, limit).map((r, i) => {
      const rate = String(r.rate||'').trim();
      const rd   = rate.startsWith('$') ? rate : (rate ? '$'+rate : '—');
      const ln   = String(r.loadNum||'').replace(/\n.*/,'').trim() || '—';
      const dt   = String(r.puDate||'').split('T')[0].substring(0, 10);
      const broker = String(r.broker||'').trim();
      const gUrl = ln !== '—' ? gmailUrl(ln) : null;
      const gmailBtn = gUrl ? `<a href="${gUrl}" target="_blank" class="dlm-gmail-btn">📧 Gmail</a>` : '';

      return `
        <div class="dlm-rec" style="border-left-color:${color};animation-delay:${i*.04}s">
          <div class="dlm-rh">
            <div style="display:flex;flex-direction:column;gap:2px;max-width:165px">
              <span class="dlm-ln">#${esc(ln)}</span>
              ${broker && broker !== 'nan' ? `<span style="font-size:11px;color:#6e6e73;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(broker)}</span>` : ''}
            </div>
            <div style="display:flex;align-items:center;gap:5px">${gmailBtn}<span class="dlm-dt">${esc(dt)}</span></div>
          </div>
          <div class="dlm-grid">
            <div class="dlm-k">Rate</div><div class="dlm-v dlm-rate">${esc(rd)}</div>
            <div class="dlm-k">From</div><div class="dlm-v">${esc(r.origin)}</div>
            ${r.destination ? `<div class="dlm-k">To</div><div class="dlm-v">${esc(r.destination)}</div>` : ''}
            ${r.weight && r.weight !== 'nan' ? `<div class="dlm-k">Wt</div><div class="dlm-v">${esc(r.weight)}</div>` : ''}
          </div>
        </div>`;
    }).join('');
  }

  // ── Scan ────────────────────────────────────────────────────────────────────
  function scan() {
    if (!odIndex && !oIndex) return;

    // Reset by creating new WeakSet (WeakSet has no .clear())
    processed = new WeakSet();
    document.querySelectorAll('.dlm-green,.dlm-yellow,.dlm-blue,.dlm-purple').forEach(r => {
      r.classList.remove('dlm-green', 'dlm-yellow', 'dlm-blue', 'dlm-purple');
      const b = r.querySelector('.dlm-badge'); if (b) b.remove();
      r.querySelectorAll('.dlm-badge-host').forEach(el => el.classList.remove('dlm-badge-host'));
    });

    // Target confirmed DAT row classes
    document.querySelectorAll('[class*="row-container"], [class*="row-cells"]').forEach(r => {
      processRow(r);
      injectEmailButton(r); // Email button on ALL rows regardless of match
    });
  }

  // ── Init ────────────────────────────────────────────────────────────────────
  async function init() {
    const s = await chrome.storage.local.get(['odIndex','oIndex','brokerIndex','laneCount','gmailIndex','senderEmail','senderGmailIndex','emailTemplate','userName','userCompany']);
    if (!s.laneCount) {
      return;
    }
    odIndex     = s.odIndex     || {};
    oIndex      = s.oIndex      || {};
    brokerIndex = s.brokerIndex || {};
    gmailIndex       = s.gmailIndex    || 0;
    senderEmail      = s.senderEmail   || '';
    senderGmailIndex = typeof s.senderGmailIndex !== 'undefined' ? s.senderGmailIndex : 0;
    userName         = s.userName      || '';
    userCompany      = s.userCompany   || '';
    emailTemplate    = s.emailTemplate || `Hi,

My name is {name} with {company}. I'm reaching out about your load from {origin} to {destination} posted on DAT today.

Can you share the rate, pickup window, and any special requirements?

Thanks,
{name}
{company}`;

    setTimeout(scan, 1200);

    const obs = new MutationObserver(() => {
      clearTimeout(_dlmT);
      _dlmT = setTimeout(scan, 600);
    });
    obs.observe(document.body, { childList: true, subtree: true });

    let lastUrl = location.href;
    setInterval(() => {
      if (location.href !== lastUrl) {
        lastUrl = location.href;
        setTimeout(scan, 1400);
      }
    }, 700);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();

})();
