// ─── CSV Parser ───────────────────────────────────────────────────────────────
function parseCSV(text) {
  const lines = text.split('\n');
  if (lines.length < 2) return [];
  const headers = splitLine(lines[0]).map(h => h.replace(/"/g,'').trim());
  const rows = [];
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    const vals = splitLine(line);
    const row = {};
    headers.forEach((h, j) => row[h] = (vals[j]||'').replace(/^"|"$/g,'').trim());
    rows.push(row);
  }
  return rows;
}
function splitLine(line) {
  const vals = []; let cur = '', inQ = false;
  for (const ch of line) {
    if (ch === '"') { inQ = !inQ; }
    else if (ch === ',' && !inQ) { vals.push(cur); cur = ''; }
    else cur += ch;
  }
  vals.push(cur); return vals;
}

// ─── Normalize ────────────────────────────────────────────────────────────────
function norm(raw) {
  if (!raw) return '';
  return String(raw).toLowerCase()
    .replace(/\bmt\b/g,   'mount')
    .replace(/\bmtn\b/g,  'mountain')
    .replace(/\bft\b/g,   'fort')
    .replace(/\bpt\b/g,   'point')
    .replace(/\blk\b/g,   'lake')
    .replace(/\bcyn\b/g,  'canyon')
    .replace(/\bvly\b/g,  'valley')
    .replace(/\bbch\b/g,  'beach')
    .replace(/\bhls\b/g,  'hills')
    .replace(/\bhts\b/g,  'heights')
    .replace(/\bhgts\b/g, 'heights')
    .replace(/\bspgs\b/g, 'springs')
    .replace(/\bspg\b/g,  'spring')
    .replace(/\bvlg\b/g,  'village')
    .replace(/\bjct\b/g,  'junction')
    .replace(/\b(ca|fl|tx|pa|nv|ga|nc|va|ct|mi|in|oh|mo|co|az|or|ut|wa|mn|ne|ks|sc|al|ms|la|ar|ky|tn|wv|md|nj|ny|ma|ri|nh|vt|me|de|nm|id|mt|wy|sd|nd|ok|ia|il|ak|hi|dc|wi)\b/g,'')
    .replace(/\d+/g,'').replace(/[^a-z\s]/g,' ').replace(/\s+/g,' ').trim();
}

// ─── Build indexes from rows ──────────────────────────────────────────────────
// IMPORTANT: we only store the indexes — NOT the raw rows array.
// This halves storage usage and fixes the 5MB overflow.
// Each record inside the index carries its fileIdx so we can remove by file later.
// Normalize broker name for fuzzy matching
function normBroker(raw) {
  if (!raw || raw === 'nan') return '';
  return String(raw).toLowerCase()
    .replace(/logistics|transport|brokerage|freight|group|inc|llc|corp|co/gi, '')
    .replace(/[^a-z\s]/g, ' ').replace(/\s+/g, ' ').trim();
}

function buildIndexesFromRows(rows, fileIdx) {
  const odIndex = {}, oIndex = {}, brokerIndex = {};
  let count = 0;

  for (const row of rows) {
    const origin  = (row['Origin']      || '').trim();
    const dest    = (row['Destination'] || '').trim();
    const rate    = (row['Rate']        || '').trim();
    const loadNum = (row['Load #']      || '').trim();
    const puDate  = (row['PU Date']     || '').trim();
    const weight  = (row['Weight \\ pallet count \\ FT'] || row['Weight'] || '').trim();

    if (!origin || origin.length < 2) continue;

    const broker  = (row['Broker'] || '').trim();
    const record = { origin, destination: dest, puDate, rate, loadNum, weight, broker, _f: fileIdx };
    count++;

    const no = norm(origin);
    const nd = norm(dest);

    if (no && nd) {
      const key = no + '|' + nd;
      if (!odIndex[key]) odIndex[key] = [];
      odIndex[key].push(record);
    }
    if (no) {
      if (!oIndex[no]) oIndex[no] = [];
      oIndex[no].push(record);
    }
    // Broker index — normalized broker name → records
    const nb = normBroker(broker);
    if (nb) {
      if (!brokerIndex[nb]) brokerIndex[nb] = [];
      brokerIndex[nb].push(record);
    }
  }
  return { odIndex, oIndex, brokerIndex, count };
}

// Merge two index objects together
// Merge two flat index objects {key: [records]}
function mergeIndexes(base, incoming) {
  const out = { ...base };
  for (const [key, recs] of Object.entries(incoming || {})) {
    if (!out[key]) out[key] = [];
    out[key] = out[key].concat(recs);
  }
  return out;
}

// Remove all records belonging to a fileIdx from an index
function removeFromIndex(index, fileIdx) {
  const out = {};
  for (const [key, recs] of Object.entries(index || {})) {
    if (!Array.isArray(recs)) continue;
    const filtered = recs.filter(r => r._f !== fileIdx);
    if (filtered.length) out[key] = filtered;
  }
  return out;
}

// Re-index file numbers after a removal
function reIndexFiles(index, removedIdx) {
  const out = {};
  for (const [key, recs] of Object.entries(index)) {
    out[key] = recs.map(r => ({
      ...r,
      _f: r._f > removedIdx ? r._f - 1 : r._f
    }));
  }
  return out;
}

function countFromIndex(odIndex) {
  let n = 0;
  const seen = new Set();
  for (const recs of Object.values(odIndex)) {
    for (const r of recs) {
      const k = r.loadNum || (r.origin + '|' + (r.destination || '') + '|' + r.puDate);
      if (!seen.has(k)) { seen.add(k); n++; }
    }
  }
  return n;
}

// ─── UI helpers ───────────────────────────────────────────────────────────────
function showError(msg) {
  const el = document.getElementById('errorMsg');
  el.textContent = msg; el.style.display = 'block';
}
function setProgress(pct, text) {
  document.getElementById('progressFill').style.width = pct + '%';
  document.getElementById('progressText').textContent = text;
}
function updateStatus(count, fileCount) {
  document.getElementById('statusBox').className = 'status-box loaded';
  document.getElementById('statusVal').textContent = `${count.toLocaleString()} lanes loaded ✓`;
  document.getElementById('statusSub').textContent = `${fileCount} file${fileCount>1?'s':''} · Ready — open DAT now`;
}

function renderFileList(files) {
  const list = document.getElementById('file-list');
  list.innerHTML = files.map((f, i) => `
    <div class="file-item">
      <span class="file-name">📄 ${f.name}</span>
      <span class="file-count">${f.count.toLocaleString()} lanes</span>
      <button class="file-remove" data-idx="${i}">✕</button>
    </div>`).join('');

  list.querySelectorAll('.file-remove').forEach(btn => {
    btn.addEventListener('click', async () => {
      const idx = parseInt(btn.dataset.idx);
      const stored = await chrome.storage.local.get(['filesMeta','odIndex','oIndex','brokerIndex']);
      let meta    = stored.filesMeta    || [];
      let odIdx   = stored.odIndex      || {};
      let oIdx    = stored.oIndex       || {};
      let brkIdx  = stored.brokerIndex  || {};

      // Remove records from indexes
      odIdx  = removeFromIndex(odIdx,  idx);
      oIdx   = removeFromIndex(oIdx,   idx);
      brkIdx = removeFromIndex(brkIdx, idx);

      // Re-number remaining file indexes
      odIdx  = reIndexFiles(odIdx,  idx);
      oIdx   = reIndexFiles(oIdx,   idx);
      brkIdx = reIndexFiles(brkIdx, idx);

      const newMeta = meta.filter((_, i) => i !== idx);
      const count   = countFromIndex(odIdx);

      await chrome.storage.local.set({ filesMeta: newMeta, odIndex: odIdx, oIndex: oIdx, brokerIndex: brkIdx, laneCount: count });
      renderFileList(newMeta);

      if (!newMeta.length) {
        document.getElementById('statusVal').textContent = 'No data loaded';
        document.getElementById('statusSub').textContent = 'Add one or more CSV files below';
        document.getElementById('statusBox').className = 'status-box';
      } else {
        updateStatus(count, newMeta.length);
      }
    });
  });
}

// ─── Account selector ─────────────────────────────────────────────────────────
function setActiveBtn(idx) {
  document.querySelectorAll('#acctBtns .acct-btn').forEach(b => {
    b.classList.toggle('active', parseInt(b.dataset.idx) === idx);
  });
}
function updateGmailStatus(email, idx) {
  const el = document.getElementById('gmailStatus');
  if (email) {
    el.textContent = `✓ ${email} · Account #${idx}`;
    el.className = 'gmail-status set';
  } else {
    el.textContent = 'Not configured yet';
    el.className = 'gmail-status unset';
  }
}

// ─── Main ─────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  const stored = await chrome.storage.local.get(['laneCount','filesMeta','gmailEmail','gmailIndex','senderEmail','senderGmailIndex','emailTemplate','userName','userCompany']);

  if (stored.laneCount && stored.filesMeta) {
    updateStatus(stored.laneCount, stored.filesMeta.length);
    renderFileList(stored.filesMeta);
  }

  // ── Sender email setting ──────────────────────────────────────────────────
  const senderInput  = document.getElementById('senderInput');
  const senderStatus = document.getElementById('senderStatus');

  if (stored.senderEmail) {
    senderInput.value = stored.senderEmail;
    senderStatus.textContent = `✓ Sending from: ${stored.senderEmail}`;
    senderStatus.className = 'gmail-status set';
  }

    // ── Sender account buttons ──────────────────────────────────────────────────
  const senderAcctBtns = document.getElementById('senderAcctBtns');
  let senderIdx = stored.senderGmailIndex !== undefined ? stored.senderGmailIndex : 0;

  function setSenderBtn(idx) {
    if (!senderAcctBtns) return;
    senderAcctBtns.querySelectorAll('.acct-btn').forEach(b => {
      b.classList.toggle('active', parseInt(b.dataset.idx) === idx);
    });
  }
  setSenderBtn(senderIdx);

  if (senderAcctBtns) {
    senderAcctBtns.addEventListener('click', async e => {
      if (!e.target.classList.contains('acct-btn')) return;
      senderIdx = parseInt(e.target.dataset.idx);
      setSenderBtn(senderIdx);
      await chrome.storage.local.set({ senderGmailIndex: senderIdx });
      const email = senderInput.value.trim();
      if (email) {
        senderStatus.textContent = `✓ Account #${senderIdx} · ${email}`;
        senderStatus.className = 'gmail-status set';
      }
    });
  }

  document.getElementById('senderSave').addEventListener('click', async () => {
    const raw = senderInput.value.trim();
    // Accept Gmail URL — auto extract account number
    const urlMatch = raw.match(/mail\.google\.com\/mail\/u\/(\d+)/);
    if (urlMatch) {
      senderIdx = parseInt(urlMatch[1]);
      setSenderBtn(senderIdx);
      await chrome.storage.local.set({ senderEmail: `Account #${senderIdx}`, senderGmailIndex: senderIdx });
      senderStatus.textContent = `✓ Outbound: Gmail Account #${senderIdx}`;
      senderStatus.className = 'gmail-status set';
      senderInput.value = '';
      senderInput.placeholder = `Account #${senderIdx} saved ✓`;
      return;
    }
    if (!raw || !raw.includes('@')) {
      senderStatus.textContent = 'Paste your Gmail URL or enter email.';
      senderStatus.className = 'gmail-status unset';
      return;
    }
    await chrome.storage.local.set({ senderEmail: raw, senderGmailIndex: senderIdx });
    senderStatus.textContent = `✓ Account #${senderIdx} · ${raw}`;
    senderStatus.className = 'gmail-status set';
  });

  // ── Your Info (name + company) ─────────────────────────────────────────────
  const userNameInput    = document.getElementById('userNameInput');
  const userCompanyInput = document.getElementById('userCompanyInput');
  const userInfoStatus   = document.getElementById('userInfoStatus');

  if (stored.userName)    userNameInput.value    = stored.userName;
  if (stored.userCompany) userCompanyInput.value = stored.userCompany;
  if (stored.userName || stored.userCompany) {
    userInfoStatus.textContent = `✓ ${stored.userName || ''} · ${stored.userCompany || ''}`.replace(/· $|^· /, '').trim();
    userInfoStatus.className = 'gmail-status set';
  }

  document.getElementById('userInfoSave').addEventListener('click', async () => {
    const name    = userNameInput.value.trim();
    const company = userCompanyInput.value.trim();
    await chrome.storage.local.set({ userName: name, userCompany: company });
    userInfoStatus.textContent = `✓ ${name}${name && company ? ' · ' : ''}${company}` || '✓ Saved';
    userInfoStatus.className = 'gmail-status set';
  });

  // ── Email template setting ─────────────────────────────────────────────────
  const DEFAULT_TEMPLATE = `Hi,

My name is {name} with {company}. I'm reaching out about your load from {origin} to {destination} posted on DAT today.

Can you share the rate, pickup window, and any special requirements?

Thanks,
{name}
{company}`;

  const templateInput  = document.getElementById('templateInput');
  const templateStatus = document.getElementById('templateStatus');

  templateInput.value = stored.emailTemplate || DEFAULT_TEMPLATE;
  if (stored.emailTemplate) {
    templateStatus.textContent = '✓ Custom template saved';
    templateStatus.className = 'gmail-status set';
  }

  document.getElementById('templateSave').addEventListener('click', async () => {
    const tmpl = templateInput.value.trim();
    if (!tmpl) return;
    await chrome.storage.local.set({ emailTemplate: tmpl });
    templateStatus.textContent = '✓ Template saved';
    templateStatus.className = 'gmail-status set';
  });

  // Gmail settings
  const savedEmail = stored.gmailEmail || '';
  const savedIdx   = stored.gmailIndex !== undefined ? stored.gmailIndex : null;
  if (savedEmail) document.getElementById('gmailInput').value = savedEmail;
  if (savedIdx !== null) setActiveBtn(savedIdx);
  updateGmailStatus(savedEmail, savedIdx);

  // Gmail save
  document.getElementById('gmailSave').addEventListener('click', async () => {
    const raw = document.getElementById('gmailInput').value.trim();
    document.getElementById('errorMsg').style.display = 'none';

    // Accept full Gmail URL — extract account number automatically
    const urlMatch = raw.match(/mail\.google\.com\/mail\/u\/(\d+)/);
    if (urlMatch) {
      const idx = parseInt(urlMatch[1]);
      setActiveBtn(idx);
      await chrome.storage.local.set({ gmailEmail: 'Account #' + idx, gmailIndex: idx });
      updateGmailStatus('Gmail Account #' + idx, idx);
      document.getElementById('gmailInput').value = '';
      document.getElementById('gmailInput').placeholder = 'Account #' + idx + ' saved ✓';
      return;
    }

    // Accept plain email address
    const activeBtn = document.querySelector('.acct-btn.active');
    const idx = activeBtn ? parseInt(activeBtn.dataset.idx) : null;
    if (!raw) { showError('Paste your Gmail URL or enter your email.'); return; }
    if (!raw.includes('@') && idx === null) { showError('Paste your Gmail URL (e.g. mail.google.com/mail/u/4/)'); return; }
    const finalIdx = idx !== null ? idx : 0;
    await chrome.storage.local.set({ gmailEmail: raw, gmailIndex: finalIdx });
    updateGmailStatus(raw, finalIdx);
  });

  // Account buttons — tap to switch account instantly
  document.getElementById('acctBtns').addEventListener('click', async e => {
    if (!e.target.classList.contains('acct-btn')) return;
    const idx = parseInt(e.target.dataset.idx);
    setActiveBtn(idx);
    const stored = await chrome.storage.local.get('gmailEmail');
    if (stored.gmailEmail) {
      await chrome.storage.local.set({ gmailIndex: idx });
      updateGmailStatus(stored.gmailEmail, idx);
    }
  });

  // File handling
  const dropZone  = document.getElementById('dropZone');
  const fileInput = document.getElementById('fileInput');
  const progress  = document.getElementById('progress');

  dropZone.addEventListener('click', () => fileInput.click());
  dropZone.addEventListener('dragover',  e => { e.preventDefault(); dropZone.classList.add('drag'); });
  dropZone.addEventListener('dragleave', () => dropZone.classList.remove('drag'));
  dropZone.addEventListener('drop', e => {
    e.preventDefault(); dropZone.classList.remove('drag');
    processFiles(Array.from(e.dataTransfer.files));
  });
  fileInput.addEventListener('change', e => processFiles(Array.from(e.target.files)));

  document.getElementById('clearBtn').addEventListener('click', async () => {
    const keep = await chrome.storage.local.get(['gmailEmail','gmailIndex','senderEmail','senderGmailIndex','emailTemplate','userName','userCompany']);
    await chrome.storage.local.clear();
    const toRestore = Object.fromEntries(Object.entries(keep).filter(([,v]) => v !== undefined));
    if (Object.keys(toRestore).length) await chrome.storage.local.set(toRestore);
    document.getElementById('statusVal').textContent = 'No data loaded';
    document.getElementById('statusSub').textContent = 'Add one or more CSV files below';
    document.getElementById('statusBox').className = 'status-box';
    document.getElementById('file-list').innerHTML = '';
    document.getElementById('errorMsg').style.display = 'none';
  });

  document.getElementById('reloadBtn').addEventListener('click', async () => {
    const tabs = await chrome.tabs.query({ url: '*://*.dat.com/*' });
    tabs.forEach(t => chrome.tabs.reload(t.id));
    window.close();
  });

  // ── Process CSV files ────────────────────────────────────────────────────────
  async function processFiles(newFiles) {
    if (!newFiles.length) return;
    const csvFiles = newFiles.filter(f => f.name.endsWith('.csv'));
    if (!csvFiles.length) { showError('Please upload CSV files only.'); return; }
    document.getElementById('errorMsg').style.display = 'none';
    const statusBox = document.getElementById('statusBox');
    statusBox.style.cssText = '';
    document.getElementById('statusVal').style.color = '';
    document.getElementById('statusSub').style.color = '';
    progress.style.display = 'block';
    setProgress(5, 'Loading existing indexes...');

    try {
      const stored = await chrome.storage.local.get(['filesMeta','odIndex','oIndex','brokerIndex','laneCount']);
      let existingMeta   = stored.filesMeta   || [];
      let existingOD     = stored.odIndex     || {};
      let existingO      = stored.oIndex      || {};
      let existingBroker = stored.brokerIndex || {};
      const startIdx    = existingMeta.length;

      const duplicate = csvFiles.find(f => existingMeta.some(m => m.name === f.name));
      if (duplicate) {
        progress.style.display = 'none';
        const box = document.getElementById('statusBox');
        const val = document.getElementById('statusVal');
        const sub = document.getElementById('statusSub');
        box.className = 'status-box';
        box.style.cssText = 'border-color:#dc2626;background:rgba(239,68,68,.07)';
        val.style.color = '#f87171';
        val.textContent = '⚠ Already uploaded';
        sub.style.color = '#f87171';
        sub.textContent = `"${duplicate.name}" is already loaded — remove it first to re-upload.`;
        return;
      }

      const newMeta = [];

      for (let i = 0; i < csvFiles.length; i++) {
        const file    = csvFiles[i];
        const fileIdx = startIdx + i;

        setProgress(15 + Math.round((i / csvFiles.length) * 50), `Parsing ${file.name}...`);

        const text = await file.text();
        const rows = parseCSV(text);

        setProgress(15 + Math.round(((i + 0.5) / csvFiles.length) * 50), `Indexing ${file.name}...`);

        const { odIndex: newOD, oIndex: newO, brokerIndex: newBroker, count } = buildIndexesFromRows(rows, fileIdx);

        if (count === 0) {
          progress.style.display = 'none';
          showError(`No lanes found in "${file.name}". Check that your CSV has columns named: Origin, Destination, Load #, PU Date, Rate.`);
          return;
        }

        // Merge into existing indexes
        existingOD     = mergeIndexes(existingOD,     newOD     || {});
        existingO      = mergeIndexes(existingO,      newO      || {});
        existingBroker = mergeIndexes(existingBroker, newBroker || {});

        newMeta.push({ name: file.name, count });
      }

      setProgress(75, 'Counting total lanes...');
      const combinedMeta = existingMeta.concat(newMeta);
      const totalCount   = combinedMeta.reduce((sum, f) => sum + f.count, 0);

      setProgress(88, 'Saving to storage...');
      try {
        await chrome.storage.local.set({
          filesMeta:   combinedMeta,
          odIndex:     existingOD,
          oIndex:      existingO,
          brokerIndex: existingBroker,
          laneCount:   totalCount,
          loadedAt:    new Date().toISOString(),
        });
      } catch (storageErr) {
        progress.style.display = 'none';
        showError('Storage full — try removing an existing file first, then re-upload.');
        return;
      }

      setProgress(100, `Done! ${totalCount.toLocaleString()} lanes ready`);
      updateStatus(totalCount, combinedMeta.length);
      renderFileList(combinedMeta);
      setTimeout(() => { progress.style.display = 'none'; }, 1500);

    } catch(err) {
      console.error('[DATMatcher]', err);
      showError('Error: ' + err.message);
      progress.style.display = 'none';
    }
  }
});
